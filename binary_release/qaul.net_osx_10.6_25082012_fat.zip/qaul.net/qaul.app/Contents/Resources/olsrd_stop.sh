#!/bin/zsh

killall olsrd


